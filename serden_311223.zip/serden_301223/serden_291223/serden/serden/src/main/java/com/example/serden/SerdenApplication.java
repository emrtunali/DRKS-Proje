package com.example.serden;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SerdenApplication {

	public static void main(String[] args) {
		SpringApplication.run(SerdenApplication.class, args);

	}
}
