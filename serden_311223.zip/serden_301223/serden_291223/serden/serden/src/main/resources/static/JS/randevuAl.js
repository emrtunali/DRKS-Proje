function aileHekimiRandevu() {  
    var abc = document.getElementById('clinicListDiv');
    abc.style.display = 'none';
}

function hastaneRandevu() {
    var abc = document.getElementById('clinicListDiv');
    abc.style.display = 'block';
}